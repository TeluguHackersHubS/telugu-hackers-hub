
pkg install wget
apt-get install ruby
wget https://github.com/busyloop/lolcat/archive/master.zip
unzip master.zip
cd lolcat-master
gem install lolcat
mv lolcat /data/data/com.termux/file/usr/bin
clear
echo '                    
            __   __     _____   __       __       _____    
           /\_\ /_/\  /\_____\ /\_\     /\_\     ) ___ (   
          ( ( (_) ) )( (_____/( ( (    ( ( (    / /\_/\ \  
           \ \___/ /  \ \__\   \ \_\    \ \_\  / /_/ (_\ \ 
           / / _ \ \  / /__/_  / / /__  / / /__\ \ )_/ / / 
          ( (_( )_) )( (_____\( (_____(( (_____(\ \/_\/ /  
           \/_/ \_\/  \/_____/ \/_____/ \/_____/ )_____(   
                                                 
' | lolcat
echo " "
echo "                             About"|lolcat
echo " "
echo "       🙏 Hey, there I am Naveen , i made this tool
  to penetrate pattern by link from termux, so i hope guys you
                             liked it. 😘"
echo ""
echo "                  Our channel :- Telugu Hackers Hub"| lolcat
echo " "
echo "			YouTube    :-  https://bit.ly/2AjKZFh " | lolcat
echo " "
echo "			Instagram  :-   https://bit.ly/3cbUPpN " | lolcat
echo " "
echo " 			facebook   :-  https://bit.ly/36E5Te4 " | lolcat
echo " " 
echo " 			website    :-  https://bit.ly/2M8S1PJ " | lolcat
echo " "


printf "\e[1;91m    [\e[0m\e[1;93m4\e[0m\e[1;91m]\e[0m\x1b[38;2;255;100;0m    exit\x1b[0m\n"
read -p $'\n\e[1;94m[\e[0m\e[1;93m*\e[0m\e[1;94m] Choose an option # \e[0m' option

if [[ $option == 4 ]]; then
exit 1

done
